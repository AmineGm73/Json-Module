from setuptools import setup, find_packages

setup(
    name='json_m',
    version='0.1.0',
    description='A useful tool to use json as database',
    packages=find_packages(),
    author='Your Name',
    author_email='aminegazit30@gmail.comAmineGM',
    install_requires=[],
)
